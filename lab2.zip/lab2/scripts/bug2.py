#!/usr/bin/env python3 
import rospy
from geometry_msgs.msg import Twist
from rospy.timer import Rate
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
import math
from visualization_msgs.msg import Marker
from geometry_msgs.msg import Point
from tf.transformations import euler_from_quaternion, quaternion_from_euler


map_x = 1
map_y = 1
map_theta = 1
lidar_range = [3 for i in range(0, 361)]

def goal_reached():

    x1 = map_x
    y1 = map_y
    x2 = 4.5
    y2 = 9.0

    goal_dist  = math.sqrt((x2-x1)**2 +(y2-y1)**2)

    goal_dist = round(goal_dist, 2)
    if goal_dist<1:
        return True
    else:
        return False


def wall_follow():
    a = lidar_range[-120]
    b = lidar_range[-1]
 
    if a == 3 and b == 3:
        return 0
    
    else:
        numerator = (a*math.cos(1.0471975512) -b)
        denominator = a*math.sin(1.0471975512)
        if denominator== 0:
            return 0
        
        alpha = math.atan(numerator/denominator)
        
        D_t = b*math.cos(alpha)
        
        A = 2*math.sin(alpha)
        
        C = D_t + A


        error = 0.8 - C

        return error

def distance_calculation(A, B,C):

    if A ==0  or B == 0 or C == 0:
        pass
    else:
        numerator = abs(A*map_x - B*map_y + C)
        denominator = math.sqrt(A**2 + B**2)
        return numerator/denominator


def turn():
    steering = Twist()
    steering.linear.x = 0
    steering.angular.z = -1.0472
    vel_pub.publish(steering)

def lidar_callback(msg):
    global lidar_range

    lidar_range = msg.ranges

def odom_callback(msg):
    global map_x
    global map_y
    global map_theta


    map_x = msg.pose.pose.position.x
    map_y = msg.pose.pose.position.y
    angle = msg.pose.pose.orientation
    angle_list = [angle.x, angle.y, angle.z, angle.w]
    (_,_,map_theta) = euler_from_quaternion(angle_list)

def move(val):

    speed = Twist()
    speed.linear.x = val 

    vel_pub.publish(speed)



def change_orientation():
    speed = Twist()
    goal = 0.72165485
    alpha = 2
    speed.angular.z = alpha * (goal - map_theta)
    vel_pub.publish(speed)


def check_obstacle():
    front_check = lidar_range[178:181] 
    for i in front_check:
        if i<2:            
            return 1
            
        else:
            return 0


def check_orientation():
    goal_orientation = 0.72165485
    num = round(goal_orientation-map_theta, 2)
    # print(num)
    num = abs(num)
    if num < 0.1:
        # if num>0:
        # # print("I was here")
        return 1
        
    else:
        # print("Hello")
        return 0

    
def travelled_distance():
    x1 = -8.0
    y1 = -2.0
    x2 = map_x
    y2 = map_y

    return math.sqrt((x2-x1)**2+(y2-y1)**2)


def bug2():
    state = 0

    forward = Twist()

    while not rospy.is_shutdown():
        reached = goal_reached()
        state = check_obstacle()
        # print("State",state)
        # print(reached, state)
        if state == 0:
            ## line following

            line_follow_state = check_orientation()
            # print("line follow state", line_follow_state)
            # print(line_follow_state)
            if line_follow_state == 0:
                # print("Cheching")
                change_orientation()
            elif line_follow_state == 1:
                # print("I am moving")
                move(2)
        elif state == 1:
            # print("wall follows")
            turn()
            while True:
                reached = goal_reached()

                if reached:
                    break

                error = wall_follow()
                alpha = 2
                steering_angle = alpha * error
                steering = Twist()
                steering.angular.z -= steering_angle
                steering.linear.x = 2

                vel_pub.publish(steering)


                x_1 = -8.0

                y_1 = -2.0

                x_2 = 4.5 

                y_2 = 9.0

                A = (y_2 - y_1)
                B = (x_2 - x_1)
                C = (x_2*y_1 - y_2*x_1)

                dist = distance_calculation(A,B,C) 
                
                dist = round(dist, 2)
                
                travel = travelled_distance()

                travel =round(travel, 2)


                if travel>3.5:
                    if dist<0.2:
                        state = 0
                        break
                        
            # print("I am outs")
            # print("state", state)

        if reached:
            break
                    
    move(0)
    return None
                


if __name__ == "__main__":

    rospy.init_node("New_trial")
    rospy.Subscriber("/odom", Odometry, odom_callback)
    rospy.Subscriber("/base_scan", LaserScan, lidar_callback)
    vel_pub = rospy.Publisher("/cmd_vel", Twist, queue_size=10)
    bug2()

    rospy.spin()