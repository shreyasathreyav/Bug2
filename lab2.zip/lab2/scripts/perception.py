#!/usr/bin/env python3 
import rospy
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
import random
import math
from visualization_msgs.msg import Marker
from visualization_msgs.msg import MarkerArray
from geometry_msgs.msg import Point


def plot(x1,y1,x2,y2):
    pass



def polar_to_cartesian(lidar_data):

    new_lidar = []
    angle_list = []

    angle_increment = 0.008726646192371845
    
    val = -1.5707963705062866
    angle_list.append(val)
    for i in range(len(lidar_data)):
        val = val + angle_increment
        angle_list.append(val)
    
    for i in range(len(lidar_data)):
        x = lidar_data[i]*math.cos(angle_list[i])
        y = lidar_data[i]*math.sin(angle_list[i])
        new_lidar.append([x,y])

    return new_lidar

def distance_calculation(points, A, B,C):

    if A == 0  or B == 0:
        pass
    else:
        numerator = abs(A*points[0] - B*points[1] + C)
        denominator = math.sqrt(A**2 + B**2)
        return numerator/denominator



def ransac(lidar_cartesian):
    
    iteration = 50
    
    inlier_list = []

    point_cloud_list = []

    outlier_list = []


    for i in range(iteration):
        
        [x_1, y_1] = random.choice(lidar_cartesian)
        [x_2, y_2] = random.choice(lidar_cartesian)      
        
        # if x_1 == 0 and x_2 == 0 or y_1 == 0 and y_2 == 0:
        #     continue
        # else:

        A = (y_2 - y_1)
        B = (x_2 - x_1)
        C = (x_2*y_1 - y_2*x_1)

        inlier = 0
        index_list = []
        point_cloud = []
        outlier = []

        for i in range(len(lidar_cartesian)):

            distance = distance_calculation(lidar_cartesian[i], A, B, C)
            # print(distance, i)
            if distance == None or distance == 0:
                pass

            else:
                if distance < 0.2:
                    inlier += 1
                    point_cloud.append(lidar_cartesian[i])
                    # print(lidar_cartesian[i])
                    # index_list.append(i)

                else:
                    outlier.append(lidar_cartesian[i])
        # point_cloud_list.append(point_cloud)
        inlier_list.append([inlier, [x_1, y_1], [x_2,y_2], point_cloud, outlier])
        # print(len(inlier_list))

    inlier_list.sort(key=lambda x:x[0])
    # print(inlier_list[3])

    outlier_list = inlier_list[-1][4]
    try:
        plotting_pointcloud = inlier_list[-1][3]
        plotting_pointcloud.sort(key=lambda x:x[0])
        pt_1 = plotting_pointcloud[0]
        plotting_pointcloud.sort(key=lambda x:x[1])
        pt_2 = plotting_pointcloud[-1]

    
        mk_list =  MarkerArray ()
        
        
        marker1 = Marker()
        point1_to_plot = Point()
        point2_to_plot = Point()
        marker1.id = 0
        marker1.header.frame_id = "base_link"
        marker1.type = Marker.LINE_STRIP
        marker1.action = Marker.ADD
        marker1.scale.x = 0.04
        marker1.color.r = 1.0
        marker1.color.a = 1.0
        point1_to_plot.x = pt_1[0]
        point1_to_plot.y = pt_1[1]
        point1_to_plot.z = 0
        point2_to_plot.x = pt_2[0]
        point2_to_plot.y = pt_2[1]
        point2_to_plot.z = 0
        marker1.points.append(point1_to_plot)
        marker1.points.append(point2_to_plot)   
        mk_list.markers.append(marker1)
        


        pub.publish(mk_list)



        iteration = 50
        
        new_inlier_list = []

        point_cloud_list = []



        for i in range(iteration):
            
            [x_1, y_1] = random.choice(outlier_list)
            [x_2, y_2] = random.choice(outlier_list)      
            
            # if x_1 == 0 and x_2 == 0 or y_1 == 0 and y_2 == 0:
            #     continue
            # else:

            A = (y_2 - y_1)
            B = (x_2 - x_1)
            C = (x_2*y_1 - y_2*x_1)

            inlier = 0
            index_list = []
            point_cloud = []
            outlier = []

            for i in range(len(outlier_list)):

                distance = distance_calculation(outlier_list[i], A, B, C)

                if distance == None or distance == 0:
                    pass

                else:
                    if distance < 0.8:
                        inlier += 1
                        point_cloud.append(outlier_list[i])
                        index_list.append(i)

                    else:
                        outlier.append(outlier_list[i])
            point_cloud_list.append(point_cloud)
            new_inlier_list.append([inlier, [x_1, y_1], [x_2,y_2], point_cloud, outlier])
            # print(len(inlier_list))

        new_inlier_list.sort(key=lambda x:x[0])

        plotting_pointcloud = new_inlier_list[-1][3]
        plotting_pointcloud.sort(key=lambda x:x[0])
        pt_1 = plotting_pointcloud[0]
        plotting_pointcloud.sort(key=lambda x:x[1])
        pt_2 = plotting_pointcloud[-1]



        marker2 = Marker()
        point1_to_plot = Point()
        point2_to_plot = Point()
        marker2.id = 1
        marker2.header.frame_id = "base_link"
        marker2.type = Marker.LINE_STRIP
        marker2.action = Marker.ADD
        marker2.scale.x = 0.04
        marker2.color.r = 1.0
        marker2.color.a = 1.0
        point1_to_plot.x = pt_1[0]
        point1_to_plot.y = pt_1[1]
        point1_to_plot.z = 0
        point2_to_plot.x = pt_2[0]
        point2_to_plot.y = pt_2[1]
        point2_to_plot.z = 0
        marker2.points.append(point1_to_plot)
        marker2.points.append(point2_to_plot)   
        mk_list.markers.append(marker2)
        
        pub.publish(mk_list)


        third_oulierlist =  new_inlier_list[-1][4]



        iteration = 50
        
        new_inlier_list = []

        point_cloud_list = []



        for i in range(iteration):
            
            [x_1, y_1] = random.choice(third_oulierlist)
            [x_2, y_2] = random.choice(third_oulierlist)      
            
            # if x_1 == 0 and x_2 == 0 or y_1 == 0 and y_2 == 0:
            #     continue
            # else:

            A = (y_2 - y_1)
            B = (x_2 - x_1)
            C = (x_2*y_1 - y_2*x_1)

            inlier = 0
            index_list = []
            point_cloud = []
            outlier = []

            for i in range(len(third_oulierlist)):

                distance = distance_calculation(third_oulierlist[i], A, B, C)

                if distance == None or distance == 0:
                    pass

                else:
                    if distance < 0.8:
                        inlier += 1
                        point_cloud.append(third_oulierlist[i])
                        index_list.append(i)

                    else:
                        outlier.append(third_oulierlist[i])
            point_cloud_list.append(point_cloud)
            new_inlier_list.append([inlier, [x_1, y_1], [x_2,y_2], point_cloud, outlier])
            # print(len(inlier_list))

        new_inlier_list.sort(key=lambda x:x[0])

        plotting_pointcloud = new_inlier_list[-1][3]
        plotting_pointcloud.sort(key=lambda x:x[0])
        pt_1 = plotting_pointcloud[0]
        plotting_pointcloud.sort(key=lambda x:x[1])
        pt_2 = plotting_pointcloud[-1]



        marker3 = Marker()
        point1_to_plot = Point()
        point2_to_plot = Point()
        marker3.id = 2
        marker3.header.frame_id = "base_link"
        marker3.type = Marker.LINE_STRIP
        marker3.action = Marker.ADD
        marker3.scale.x = 0.04
        marker3.color.r = 1.0
        marker3.color.a = 1.0
        point1_to_plot.x = pt_1[0]
        point1_to_plot.y = pt_1[1]
        point1_to_plot.z = 0
        point2_to_plot.x = pt_2[0]
        point2_to_plot.y = pt_2[1]
        point2_to_plot.z = 0
        marker3.points.append(point1_to_plot)
        marker3.points.append(point2_to_plot)   
        mk_list.markers.append(marker3)
        
        pub.publish(mk_list)



        

    except:
        pass
    


    
    # min_x = 0
    
    # for i in range(len(plotting_pointcloud)):
    #     if plotting_pointcloud[i]<min_x:


    # if len(inlier_list)>0:

    #     plot(inlier_list[-1][1][0], inlier_list[-1][1][1],  inlier_list[-1][2][0],inlier_list[-1][2][1])

    # if len(inlier_list)>=0:
    #         print(inlier_list[-1][4])
    #         s = {i for i in range(361)}
    #         sl = set(inlier_list[-1][4])
    #         new = s -sl
            
    #         for i in new:
    #             new_list.append(lidar_cartesian[i])
    

    # ransac(new_list)



def callback(msg):

    test = all(element == 3.0 for element in msg.ranges)
    if (test):
        pass
    else:
        new_list = list(msg.ranges)
        for i in range(len(new_list)):
            if new_list[i] == 3.0:
                new_list[i] = 0             
        angle_min = msg.angle_min
        increment = msg.angle_increment
        lidar_cartesian = polar_to_cartesian(new_list)

        ransac(lidar_cartesian)



if __name__ == "__main__":
    rospy.init_node("ransac")
    rospy.Subscriber("/base_scan", LaserScan, callback)
    pub = rospy.Publisher("ransac_viz", MarkerArray, queue_size=10)

    rospy.spin()